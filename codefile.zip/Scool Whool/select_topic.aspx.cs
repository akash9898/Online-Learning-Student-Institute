﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class select_topic : System.Web.UI.Page
{

    void video_data_fill_rpt(int fillterval)
    {
        subject_masterBAL stdmBAL = new subject_masterBAL();
        if (fillterval == 0)
        {
            stdmBAL.filtertopic = 0;
        }
        if (fillterval == 1)
        {
            stdmBAL.filtertopic = 1;
            stdmBAL.topic_id = Convert.ToInt16(drmaintopic.SelectedItem.Value);
        }
        if (fillterval == 2)
        {
            stdmBAL.filtertopic = 2;
            stdmBAL.sub_topic_id = Convert.ToInt16(drsubtopic.SelectedItem.Value);
        }
        if (fillterval == 3)
        {
            stdmBAL.filtertopic = 3;
            stdmBAL.third_topic_id = Convert.ToInt16(drthirdtopic.SelectedItem.Value);
        }
        stdmBAL.subject_id = Convert.ToInt16(Request.QueryString["kfafa"].ToString());
        fillter_topic_video stdmDAL = new fillter_topic_video();
        DataSet ds = stdmDAL.video_master_data_fill_subjectid_video_data(stdmBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            rptvideofill.DataSource = ds;
            rptvideofill.DataBind();
        }
        else
        {
            rptvideofill.DataSource = null;
            rptvideofill.DataBind();
        }
    }
    void fill_profile_data()
    {
        student_details_BAL sdBAL = new student_details_BAL();
        sdBAL.stud_id = Convert.ToInt16(Session["clientlogin"].ToString());

        student_details_DAL sdDAL = new student_details_DAL();
        DataSet ds = sdDAL.student_details_edit(sdBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            lbluserName.InnerText = ds.Tables[0].Rows[0]["stud_first_name"].ToString();
        }
    }
    void insitute_data_fill_notice_menu()
    {
        student_institute_link_BAL sdlBAL = new student_institute_link_BAL();
        sdlBAL.sil_verification_status = "1";
        sdlBAL.sil_stud_id = Convert.ToInt16(Session["clientlogin"].ToString());

        student_institute_link_DAL sdlDAL = new student_institute_link_DAL();
        DataSet ds = sdlDAL.student_institute_link_data_fill_verification_state_studant_data_show_institute(sdlBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            noticeinstitute.DataSource = ds;
            noticeinstitute.DataBind();
        }
        else
        {
            noticeinstitute.DataSource = null;
            noticeinstitute.DataBind();
        }

    }
    void main_topic_data_fill_drop()
    {
        topic_masterBAL tpmBAL = new topic_masterBAL();
        tpmBAL.topic_subject_id = Convert.ToInt16(Request.QueryString["kfafa"].ToString());

        topic_masterDAL tmDAL = new topic_masterDAL();
        DataSet ds = tmDAL.topic_drop_down_fill(tpmBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            drmaintopic.DataSource = ds;
            drmaintopic.DataTextField = "topic_name";
            drmaintopic.DataValueField = "topic_id";
            drmaintopic.DataBind();

            drmaintopic.Items.Insert(0, new ListItem("Select Main Topic", "0"));

        }
        else
        {
            drmaintopic.Items.Clear();
            drmaintopic.Items.Insert(0, new ListItem("Select Main Topic", "0"));
        }
    }
    void sub_topic_data_fill_drop()
    {
        sub_topic_masterBAL stpBAL = new sub_topic_masterBAL();
        stpBAL.sub_topic_topic_id = Convert.ToInt16(drmaintopic.SelectedItem.Value);
        sub_topic_masterDAL stpDAL = new sub_topic_masterDAL();
        DataSet ds = stpDAL.get_sub_topic_for_dropdownfill(stpBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            drsubtopic.DataSource = ds;
            drsubtopic.DataTextField = "sub_topic_name";
            drsubtopic.DataValueField = "sub_topic_id";
            drsubtopic.DataBind();

            drsubtopic.Items.Insert(0, new ListItem("Select Sub Topic", "0"));

        }
        else
        {
            drsubtopic.Items.Clear();
            drsubtopic.Items.Insert(0, new ListItem("Select Sub Topic", "0"));
        }
    }
    void thitd_topic_data_fill_drop()
    {
        third_topic_masterBAL thtpBAL = new third_topic_masterBAL();
        thtpBAL.third_topic_sub_topic_id = Convert.ToInt16(drsubtopic.SelectedItem.Value);


        third_topic_masterDAL thtpDAL = new third_topic_masterDAL();
        DataSet ds = thtpDAL.get_third_topic_for_dropdownfill(thtpBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            drthirdtopic.DataSource = ds;
            drthirdtopic.DataTextField = "third_topic_name";
            drthirdtopic.DataValueField = "third_topic_id";
            drthirdtopic.DataBind();

            drthirdtopic.Items.Insert(0, new ListItem("Select Sub Topic", "0"));

        }
        else
        {
            drthirdtopic.Items.Clear();
            drthirdtopic.Items.Insert(0, new ListItem("Select Sub Topic", "0"));
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["clientlogin"] != null)
            {
                main_topic_data_fill_drop();
                insitute_data_fill_notice_menu();
                drsubtopic.Items.Insert(0, new ListItem("Select Sub Topic", "0"));
                drthirdtopic.Items.Insert(0, new ListItem("Select Third Topic", "0"));
                logoutdiv.Visible = true;
                logindiv.Visible = false;
                homeli.Visible = false;
                fill_profile_data();
                video_data_fill_rpt(0);
            }
            else
            {
                Response.Redirect("log_in.aspx");
            }
        }
    }
    protected void drmaintopic_SelectedIndexChanged(object sender, EventArgs e)
    {
        sub_topic_data_fill_drop();

        video_data_fill_rpt(1);
    }
    protected void drsubtopic_SelectedIndexChanged(object sender, EventArgs e)
    {
        thitd_topic_data_fill_drop();

        video_data_fill_rpt(2);
    }
    protected void drthirdtopic_SelectedIndexChanged(object sender, EventArgs e)
    {

        video_data_fill_rpt(3);
    }
}