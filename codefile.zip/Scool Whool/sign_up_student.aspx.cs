﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class sign_up_student : System.Web.UI.Page
{
    void standard_data_fill_drop()
    {
        standard_masterDAL smDAL = new standard_masterDAL();
        DataSet ds = smDAL.get_all_standard();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drstandard.DataSource = ds;
            drstandard.DataTextField = "standard_name";
            drstandard.DataValueField = "standard_id";
            drstandard.DataBind();
            drstandard.Items.Insert(0, new ListItem("Select Standard", "0"));
        }
        else
        {
            drstandard.Items.Clear();
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            standard_data_fill_drop();
        }
    }
    protected void btnstudant_Click(object sender, EventArgs e)
    {
        student_details_BAL sdBAL = new student_details_BAL();
        if (hfboardid.Value != null & hfboardid.Value.ToString() != "")
        {
            sdBAL.stud_id = Convert.ToInt16(hfboardid.Value.ToString());
        }
        else
        {
            sdBAL.stud_id = 0;
        }
        sdBAL.stud_first_name = txtfistname.Text;
        sdBAL.stud_middle_name = txtmiddelname.Text;
        sdBAL.stud_last_name = txtlastname.Text;
        if (rdomale.Checked == true)
        {
            sdBAL.stud_gender = "Male";
        }
        else if (rdofemale.Checked == true)
        {
            sdBAL.stud_gender = "Female";
        }
        sdBAL.stud_mobile_no = txtmobilno.Text;
        sdBAL.stud_dob = txtDOB.Text;
        sdBAL.stud_std_id = Convert.ToInt16(drstandard.SelectedItem.Value);
        sdBAL.stud_email = txtemail.Text;
        sdBAL.stud_password = txtpassword.Text;
        sdBAL.stud_status = "0";
        sdBAL.stud_insdt = System.DateTime.Now;
        sdBAL.stud_insip = "1";
        sdBAL.stud_insrid = 0;
        sdBAL.stud_logdt = System.DateTime.Now;
        sdBAL.stud_logip = "1";
        sdBAL.stud_logrid = 0;

        student_details_DAL sdDAL = new student_details_DAL();
        int val = sdDAL.student_details_insert(sdBAL);
        if (val == 0)
        {
            Response.Write("<script>alert('The same contact details are linked with some other account please try to change mobile number or email');</script>");
        }
        else if (val > 0)
        {
            Session["clientlogin"] = val;
            Response.Write("<script>alert('Thanks for signing up');window.location.href='institute_link_studant.aspx';</script>");

        }
        //else if (val.ToString() == "3")
        //{
        //    Response.Write("<script>alert('Institute data updated.');window.location.href='sign_up_student.aspx';</script>");
        //}

    }
}