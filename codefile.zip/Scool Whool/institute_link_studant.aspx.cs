﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class institute_link_studant : System.Web.UI.Page
{
    void institute_link_studant_fill_data_rpt()
    {
        student_institute_link_BAL sdlBAL = new student_institute_link_BAL();
        sdlBAL.sil_stud_id = Convert.ToInt16(Session["clientlogin"].ToString());

        student_institute_link_DAL sdlDAL = new student_institute_link_DAL();
        DataSet ds = sdlDAL.student_institute_link_data_fill_verification_state_studant_data(sdlBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeaterdebit.DataSource = ds;
            gridrepeaterdebit.DataBind();
        }
        else
        {
            gridrepeaterdebit.DataSource = null;
            gridrepeaterdebit.DataBind();
        }
    }
    void fill_profile_data()
    {
        student_details_BAL sdBAL = new student_details_BAL();
        sdBAL.stud_id = Convert.ToInt16(Session["clientlogin"].ToString());

        student_details_DAL sdDAL = new student_details_DAL();
        DataSet ds = sdDAL.student_details_edit(sdBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            lbluserName.InnerText = ds.Tables[0].Rows[0]["stud_first_name"].ToString();
        }
    }
    void insitute_data_fill_notice_menu()
    {
        student_institute_link_BAL sdlBAL = new student_institute_link_BAL();
        sdlBAL.sil_verification_status = "1";
        sdlBAL.sil_stud_id = Convert.ToInt16(Session["clientlogin"].ToString());

        student_institute_link_DAL sdlDAL = new student_institute_link_DAL();
        DataSet ds = sdlDAL.student_institute_link_data_fill_verification_state_studant_data_show_institute(sdlBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            noticeinstitute.DataSource = ds;
            noticeinstitute.DataBind();
        }
        else
        {
            noticeinstitute.DataSource = null;
            noticeinstitute.DataBind();
        }

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            if (Session["clientlogin"] != null)
            {
                institute_link_studant_fill_data_rpt();
                logoutdiv.Visible = true;
                logindiv.Visible = false;
                homeli.Visible = false;
                fill_profile_data();
                insitute_data_fill_notice_menu();
            }
            else
            {
                Response.Redirect("log_in.aspx");
            }
        }
    }
    protected void btninstitutecode_Click(object sender, EventArgs e)
    {
        institute_details_BAL idBAL = new institute_details_BAL();
        idBAL.id_mobile_no = txtmobileno.Text;
        idBAL.id_verification_status = "1";

        institute_details_DAL idDAL = new institute_details_DAL();
        DataSet ds = idDAL.institute_details_data_fill_chack_verirfication_institute_code(idBAL);

        if (ds.Tables[0].Rows.Count > 0)
        {
            student_institute_link_BAL sdlBAL = new student_institute_link_BAL();
            sdlBAL.sil_id = 0;
            sdlBAL.sil_stud_id = Convert.ToInt16(Session["clientlogin"].ToString());
            sdlBAL.sil_verification_status = "0";
            sdlBAL.institute_code_no = txtmobileno.Text;

            student_institute_link_DAL sdlDAL = new student_institute_link_DAL();
            int val = sdlDAL.student_institute_link_insert(sdlBAL);
            if (val == 0)
            {
                Response.Write("<script>alert('You are already linked with this institute');</script>");
            }
            else if (val > 0)
            {
                Response.Write("<script>alert('Request for institute link received successfully !! Please wait for the approval from institute');window.location.href='institute_link_studant.aspx';</script>");
            }
            else if (val == -1)
            {
                Response.Write("<script>alert('Wrong institute code');</script>");
            }
        }
        else
        {
            Response.Write("<script>alert('Your Institute In Not Registration.');</script>");
        }
      

    }
}