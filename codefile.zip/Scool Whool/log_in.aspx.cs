﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class log_in : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["clientlogin"] != null)
        {
            Session["clientlogin"] = null;
            Session.Clear();
            Session.Abandon();
        }
    }
    protected void btuserlogin_Click(object sender, EventArgs e)
    {
        student_details_BAL sdBAL = new student_details_BAL();
        sdBAL.stud_mobile_no = txtmobileno.Text;
        sdBAL.stud_password = txtpassword.Text;

        student_details_DAL sdDAL = new student_details_DAL();
        DataSet ds = sdDAL.student_details_login_data_fill(sdBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Session["clientlogin"] = ds.Tables[0].Rows[0]["stud_id"].ToString();
            Response.Redirect("homepage_after_login.aspx");
        }
        else
        {
            Response.Write("<script>alert('Mobile No or Password is worng')</script>");
        }
    }
}