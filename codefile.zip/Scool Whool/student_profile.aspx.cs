﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class student_profile : System.Web.UI.Page
{
    void fill_profile_data()
    {
        student_details_BAL sdBAL = new student_details_BAL();
        sdBAL.stud_id = Convert.ToInt16(Session["clientlogin"].ToString());

        student_details_DAL sdDAL = new student_details_DAL();
        DataSet ds = sdDAL.student_details_edit(sdBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            lbluserName.InnerText = ds.Tables[0].Rows[0]["stud_first_name"].ToString();
        }
    }
    void insitute_data_fill_notice_menu()
    {
        student_institute_link_BAL sdlBAL = new student_institute_link_BAL();
        sdlBAL.sil_verification_status = "1";
        sdlBAL.sil_stud_id = Convert.ToInt16(Session["clientlogin"].ToString());

        student_institute_link_DAL sdlDAL = new student_institute_link_DAL();
        DataSet ds = sdlDAL.student_institute_link_data_fill_verification_state_studant_data_show_institute(sdlBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            noticeinstitute.DataSource = ds;
            noticeinstitute.DataBind();
        }
        else
        {
            noticeinstitute.DataSource = null;
            noticeinstitute.DataBind();
        }

    }
    void standard_master_data_fill()
    {
        standard_masterDAL smDAL = new standard_masterDAL();
        DataSet ds = smDAL.get_all_standard();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drstandard.DataSource = ds;
            drstandard.DataTextField = "standard_name";
            drstandard.DataValueField = "standard_id";
            drstandard.DataBind();
            drstandard.Items.Insert(0, new ListItem("Select Standard", "0"));
        }
        else
        {
            drstandard.Items.Clear();
            drstandard.Items.Insert(0, new ListItem("Select Standard", "0"));

        }
    }
    void student_details_data_fill()
    {
        student_details_BAL sdBAL = new student_details_BAL();
        sdBAL.stud_id = Convert.ToInt16(Session["clientlogin"].ToString());

        student_details_DAL sdDAL = new student_details_DAL();
        DataSet ds = sdDAL.student_details_edit(sdBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            txtfistname.Text = ds.Tables[0].Rows[0]["stud_first_name"].ToString();
            txtmiddelname.CssClass = "form-control mt-2";
            txtfistname.Enabled = false;

            txtmiddelname.Text = ds.Tables[0].Rows[0]["stud_middle_name"].ToString();
            txtmiddelname.CssClass = "form-control mt-2";
            txtmiddelname.Enabled = false;

            txtlastname.Text = ds.Tables[0].Rows[0]["stud_last_name"].ToString();
            txtlastname.CssClass = "form-control mt-2";
            txtlastname.Enabled = false;

            if (ds.Tables[0].Rows[0]["stud_gender"].ToString() == "Male")
            {
                rdomale.Checked = true;
            }
            else if (ds.Tables[0].Rows[0]["stud_gender"].ToString() == "Female")
            {
                rdofemale.Checked = true;
            }

            txtDOB.Text = ds.Tables[0].Rows[0]["stud_dob"].ToString();
            txtDOB.CssClass = "form-control mt-2";
            txtDOB.Enabled = false;

            drstandard.Text = ds.Tables[0].Rows[0]["stud_std_id"].ToString();
            drstandard.CssClass = "form-control mt-2";
            drstandard.Enabled = false;

            txtmobilno.Text = ds.Tables[0].Rows[0]["stud_mobile_no"].ToString();
            txtmobilno.CssClass = "form-control mt-2";
            txtmobilno.Enabled = false;

            txtemail.Text = ds.Tables[0].Rows[0]["stud_email"].ToString();
            txtemail.CssClass = "form-control mt-2";
            txtemail.Enabled = false;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["clientlogin"] != null)
            {
                logoutdiv.Visible = true;
                logindiv.Visible = false;
                //lblaboutus.Visible = false;
                //contact.Visible = false;
                fill_profile_data();
                insitute_data_fill_notice_menu();
                standard_master_data_fill();
                student_details_data_fill();
                passworddiv.Visible = false;
            }
            else
            {
                Notice.Visible = false;
                insituteadd.Visible = false;
                instituteyour.Visible = false;
            }

          
        }
    }

    protected void btnedit_Click(object sender, EventArgs e)
    {
        txtfistname.Enabled = true;
        txtlastname.Enabled = true;
        txtmiddelname.Enabled = true;
        txtDOB.Enabled = true;
        drstandard.Enabled = true;
        txtmobilno.Enabled = true;
        txtemail.Enabled = true;
        btnedit.Visible = false;
        btnstudant.Visible = true;
        //passworddiv.Visible = true;

    }
    protected void btnstudant_Click(object sender, EventArgs e)
    {
        student_details_BAL sdBAL = new student_details_BAL();
        sdBAL.stud_id = Convert.ToInt16(Session["clientlogin"].ToString());
        sdBAL.stud_first_name = txtfistname.Text;
        sdBAL.stud_middle_name = txtmiddelname.Text;
        sdBAL.stud_last_name = txtlastname.Text;
        if (rdomale.Checked == true)
        {
            sdBAL.stud_gender = "Male";
        }
        else if (rdofemale.Checked == true)
        {
            sdBAL.stud_gender = "Female";
        }
        sdBAL.stud_mobile_no = txtmobilno.Text;
        sdBAL.stud_dob = txtDOB.Text;
        sdBAL.stud_std_id = Convert.ToInt16(drstandard.SelectedItem.Value);
        sdBAL.stud_email = txtemail.Text;
        sdBAL.stud_logdt = System.DateTime.Now;
        sdBAL.stud_logip = "1";
        sdBAL.stud_logrid = 0;
        student_details_DAL sdDAL = new student_details_DAL();
        int val = sdDAL.student_details_insert(sdBAL);
        if (val.ToString() == "-1")
        {
            Response.Write("<script>alert('Studant data updated.');window.location.href='student_profile.aspx';</script>");
        }
    }
}