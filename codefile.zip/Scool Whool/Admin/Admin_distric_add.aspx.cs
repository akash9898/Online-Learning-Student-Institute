﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class admin_Admin_distric_add : System.Web.UI.Page
{
    void rptr_gridfilldata()
    {
        alladdress_get_data_DAL allDAL = new alladdress_get_data_DAL();
        DataSet ds = allDAL.distric_data();

        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }

    void country_data()
    {
        alladdress_get_data_DAL allDAL = new alladdress_get_data_DAL();
        DataSet ds = allDAL.state_data();

        if (ds.Tables[0].Rows.Count > 0)
        {
            drState.DataSource = ds;
            drState.DataTextField = "state_name";
            drState.DataValueField = "state_id";
            drState.DataBind();
            drState.Items.Insert(0, "---: Select State :---");
        }
        else
        {
            drState.DataSource = null;
            drState.DataBind();
            drState.Items.Insert(0, "---Select State--");
        }

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["admin_login"] != null)
            {
            country_data();
            rptr_gridfilldata();
            }
            else
            {
                Response.Redirect("Admin_Login.aspx");
            }
        }
    }
   
    protected void btnevent_Click(object sender, EventArgs e)
    {
       
            if (drState.SelectedIndex != 0)
            {
                distric_master_BAL dmBAL = new distric_master_BAL();
                if (hfprdid.Value == "")
                {
                    dmBAL.distric_id = 0;
                }
                else
                {
                    dmBAL.distric_id = Convert.ToInt16(hfprdid.Value);
                }
                dmBAL.distric_state_id = Convert.ToInt16(drState.SelectedValue);
                dmBAL.distric_name = txtDistricname.Text.Trim().ToUpper();
                dmBAL.distric_insdt = System.DateTime.Now.ToString("yyyy/MM/dd");
                dmBAL.distric_insrid = Convert.ToInt16(Session["admin_login"].ToString());
                dmBAL.distric_logdt = System.DateTime.Now.ToString("yyyy/MM/dd");
                dmBAL.distric_logrid = Convert.ToInt16(Session["admin_login"].ToString());

                alladdress_insert_data_DAL allinDAL = new alladdress_insert_data_DAL();
                int val = allinDAL.distric_data_insert(dmBAL);
                if (val == 1)
                {
                    // show message for alredy exists
                    Response.Write("<script>alert('This Distric is exists.')</script>");

                }
                else if (val == 2)
                {
                    // insert
                    Response.Write("<script>alert('Distric data inserted.');window.location.href='Admin_distric_add.aspx';</script>");
                }
                else if (val == 3)
                {
                    Response.Write("<script>alert('Distric data updated.');window.location.href='Admin_distric_add.aspx';</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('Select your state.')</script>");
            }
       
    }
    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "editdata")
        {
            distric_master_BAL stBAL = new distric_master_BAL();
            stBAL.distric_id = Convert.ToInt16(e.CommandArgument.ToString());

            alladdress_edit_data_DAL aleDAL = new alladdress_edit_data_DAL();
            DataSet ds = aleDAL.distric_data_edit(stBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {

                drState.SelectedValue = ds.Tables[0].Rows[0]["distric_state_id"].ToString();
                txtDistricname.Text = ds.Tables[0].Rows[0]["distric_name"].ToString();
                hfprdid.Value = ds.Tables[0].Rows[0]["distric_id"].ToString();
            }

        }

    }
}