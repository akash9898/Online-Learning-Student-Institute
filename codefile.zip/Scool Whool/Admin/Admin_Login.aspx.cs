﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class Admin_Admin_Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["userrole"] != null)
        {
            Session["userrole"] = null;
            Session.Clear();
            Session.Abandon();
        }

        if (Session["admin_login"] != null)
        {
            Session["admin_login"] = null;
            Session.Clear();
            Session.Abandon();
        }
    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {
        //try
        //{
        //if (FingerPrint.Value().ToString() == "BFEBFBFF000306A9-American Megatrends Inc.2.10012345678920140109000000.000000+000SUPERM - 1-ST1000NM0033-9ZM173(Standard disk drives)325889255")
        //{
        if (Session["userrole"] != null)
        {
            Session["userrole"] = null;
            Session.Clear();
            Session.Abandon();
        }

        if (Session["admin_login"] != null)
        {
            Session["admin_login"] = null;
            Session.Clear();
            Session.Abandon();
        }

        admin_user_masterBAL aumBAL = new admin_user_masterBAL();
        aumBAL.aum_contactno = txtmobileno.Text;
        aumBAL.aum_password = txtpassword.Text;
        admin_user_masterDAL aumDAL = new admin_user_masterDAL();
        string[] returnvalue = aumDAL.admin_user_login(aumBAL).Split('|');
        if (returnvalue[0].ToString() != "0")
        {
            if (returnvalue[0].ToString() != "1")
            {
                if (returnvalue[0].ToString() == "2")
                {
                    Session["userrole"] = returnvalue[2].ToString();
                    Session["admin_login"] = returnvalue[1].ToString();
                    Response.Redirect("~/Admin/Admin_Dashboard.aspx");
                }
            }
            else
            {
                Response.Write("<script>alert('You are deactive user you can not access system please contact administrator to re activate.');</script>");
            }
        }
        else
        {
            Response.Write("<script>alert('Mobile No or Password Wrong');</script>");
        }
        //}
        //else
        //{
        //    Response.Write("<script>alert('This product is not registered please contact developer');</script>");
        //}
        //}
        //catch (Exception ex)
        //{
        //    throw;
        //}
    }

    protected void lnkbtnforgetps_Click(object sender, EventArgs e)
    {
        Response.Write("<script>alert('Please contact managment to change password');</script>");

    }


    //protected void btndate_Click(object sender, EventArgs e)
    //{
    //    Label1.Text = System.DateTime.Now.ToString();
    //}
}