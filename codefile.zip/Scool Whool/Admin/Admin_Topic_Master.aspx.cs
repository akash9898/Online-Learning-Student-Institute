﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class Admin_Admin_Topic_Master : System.Web.UI.Page
{
    void fillsubjectdropdown()
    {
        subject_masterDAL sbjDAL = new subject_masterDAL();
        DataSet ds = sbjDAL.get_all_subject();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drsubject.DataSource = ds;
            drsubject.DataTextField = "subject_name";
            drsubject.DataValueField = "subject_id";
            drsubject.DataBind();
            drsubject.Items.Insert(0, "--- Select Subject Name ---");
            drsubject.Items[0].Value = "0";

        }
        else
        {
            drsubject.Items.Clear();
        }
    }
    void fillgrid()
    {
        topic_masterDAL mdmDAL = new topic_masterDAL();
        DataSet ds = mdmDAL.get_all_topic();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["admin_login"] != null)
        {
            if (!IsPostBack)
            {
                fillsubjectdropdown();
                fillgrid();
            }
        }
        else
        {
            Response.Redirect("~/Admin/Admin_Login.aspx");
        }
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        topic_masterBAL tpBAL = new topic_masterBAL();
        if (hftopicid.Value != null & hftopicid.Value.ToString() != "")
        {
            tpBAL.topic_id = Convert.ToInt16(hftopicid.Value.ToString());
        }
        else
        {
            tpBAL.topic_id = 0;
        }
        tpBAL.topic_subject_id = Convert.ToInt16(drsubject.SelectedItem.Value);
        tpBAL.topic_name = txttpname.Text.Trim().ToUpper();
        tpBAL.topic_insdt = System.DateTime.Now;
        tpBAL.topic_insip = "1";
        tpBAL.topic_insrid = Convert.ToInt16(Session["admin_login"].ToString());
        tpBAL.topic_logdt = System.DateTime.Now;
        tpBAL.topic_logip = "1";
        tpBAL.topic_logrid = Convert.ToInt16(Session["admin_login"].ToString());
        topic_masterDAL mdmDAL = new topic_masterDAL();
        int rid = mdmDAL.topic_master_add_update(tpBAL);
        if (rid.ToString() == "0")
        {
            Response.Write("<script>alert('Error in server');</script>");
        }
        else if (rid.ToString() == "1")
        {
            Response.Write("<script>alert('This topic exists already');</script>");
        }
        else if (rid.ToString() == "2")
        {
            Response.Write("<script>alert('topic inserted');</script>");
        }
        else if (rid.ToString() == "3")
        {
            Response.Write("<script>alert('topic data updated.');</script>");
        }
        fillgrid();
    }
    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "btnrptredit")
        {
            topic_masterBAL tpBAL = new topic_masterBAL();
            tpBAL.topic_id = Convert.ToInt16(e.CommandArgument.ToString());
            topic_masterDAL mdmDAL = new topic_masterDAL();
            DataSet ds = mdmDAL.get_single_topic_detail(tpBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                hftopicid.Value = ds.Tables[0].Rows[0]["topic_id"].ToString();
                txttpname.Text = ds.Tables[0].Rows[0]["topic_name"].ToString();
                drsubject.Text = ds.Tables[0].Rows[0]["topic_subject_id"].ToString();
            }
            else
            {
                Response.Write("<script>alert('Such data does not exists');</script>");
            }
        }
    }

   
}