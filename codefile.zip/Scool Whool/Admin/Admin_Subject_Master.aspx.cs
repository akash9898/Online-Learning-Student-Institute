﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;

public partial class Admin_Admin_Subject_Master : System.Web.UI.Page
{
    void fillgrid()
    {
        subject_masterDAL subjDAL = new subject_masterDAL();
        DataSet ds = subjDAL.get_all_subject();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["admin_login"] != null)
        {
            if (!IsPostBack)
            {
                fillgrid();
            }
        }
        else
        {
            Response.Redirect("~/Admin/Admin_Login.aspx");
        }
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        subject_masterBAL subjBAL = new subject_masterBAL();
        if (hfsubjid.Value != null & hfsubjid.Value.ToString() != "")
        {
            subjBAL.subject_id = Convert.ToInt16(hfsubjid.Value.ToString());
        }
        else
        {
            subjBAL.subject_id = 0;
        }
        subjBAL.subject_name = txtsubjectname.Text.Trim().ToUpper();
        if (filesubject.HasFile)
        {
            Guid a = Guid.NewGuid();
            hfufdpassextension.Value = Path.GetExtension(filesubject.FileName);
            hfufdpassnewname.Value = a.ToString() + hfufdpassextension.Value;
            filesubject.SaveAs(Server.MapPath("~/Admin/subjectimage/" + hfufdpassnewname.Value));
            subjBAL.subject_image = "~/Admin/subjectimage/" + hfufdpassnewname.Value;

            //filesubject.SaveAs(Server.MapPath("~/Admin/subjectimage/" + filesubject.FileName));
            //subjBAL.subject_image = "~/Admin/subjectimage/" + filesubject.FileName;
        }
        else
        {
            subjBAL.subject_image = imagesubject.ImageUrl;
        }
        subjBAL.subject_insdt = System.DateTime.Now;
        subjBAL.subject_insip = "1";
        subjBAL.subject_insrid = Convert.ToInt16(Session["admin_login"].ToString());
        subjBAL.subject_logdt = System.DateTime.Now;
        subjBAL.subject_logip = "1";
        subjBAL.subject_logrid = Convert.ToInt16(Session["admin_login"].ToString());
        subject_masterDAL subjDAL = new subject_masterDAL();
        int rid = subjDAL.subject_master_add_update(subjBAL);
        if (rid.ToString() == "0")
        {
            Response.Write("<script>alert('Error in server');</script>");
        }
        else if (rid.ToString() == "1")
        {
            Response.Write("<script>alert('This subject exists already');</script>");
        }
        else if (rid.ToString() == "2")
        {
            Response.Write("<script>alert('subject inserted');</script>");
        }
        else if (rid.ToString() == "3")
        {
            Response.Write("<script>alert('subject data updated.');</script>");
        }
        fillgrid();
    }
    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "btnrptredit")
        {
            subject_masterBAL subjBAL = new subject_masterBAL();
            subjBAL.subject_id = Convert.ToInt16(e.CommandArgument.ToString());
            subject_masterDAL subjDAL = new subject_masterDAL();
            DataSet ds = subjDAL.get_single_subject_detail(subjBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                imagesubject.Visible = true;
                hfsubjid.Value = ds.Tables[0].Rows[0]["subject_id"].ToString();
                txtsubjectname.Text = ds.Tables[0].Rows[0]["subject_name"].ToString();
                imagesubject.ImageUrl = ds.Tables[0].Rows[0]["subject_image"].ToString();
            }
            else
            {
                Response.Write("<script>alert('Such data does not exists');</script>");
            }
        }
    }

}