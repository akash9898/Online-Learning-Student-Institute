﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class Admin_Admin_Board_Master : System.Web.UI.Page
{
    void fillgrid()
    {
        board_masterDAL mdmDAL = new board_masterDAL();
        DataSet ds = mdmDAL.get_all_board();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["admin_login"] != null)
        {
            if (!IsPostBack)
            {
                fillgrid();
            }
        }
        else
        {
            Response.Redirect("~/Admin/Admin_Login.aspx");
        }
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        board_masterBAL subjBAL = new board_masterBAL();
        if (hfboardid.Value != null & hfboardid.Value.ToString() != "")
        {
            subjBAL.board_id = Convert.ToInt16(hfboardid.Value.ToString());
        }
        else
        {
            subjBAL.board_id = 0;
        }
        subjBAL.board_name = txtboardname.Text.Trim().ToUpper();
        subjBAL.board_insdt = System.DateTime.Now;
        subjBAL.board_insip = "1";
        subjBAL.board_insrid = Convert.ToInt16(Session["admin_login"].ToString());
        subjBAL.board_logdt = System.DateTime.Now;
        subjBAL.board_logip = "1";
        subjBAL.board_logrid = Convert.ToInt16(Session["admin_login"].ToString());
        board_masterDAL mdmDAL = new board_masterDAL();
        int rid = mdmDAL.board_master_add_update(subjBAL);
        if (rid.ToString() == "0")
        {
            Response.Write("<script>alert('Error in server');</script>");
        }
        else if (rid.ToString() == "1")
        {
            Response.Write("<script>alert('This board exists already');</script>");
        }
        else if (rid.ToString() == "2")
        {
            Response.Write("<script>alert('board inserted');</script>");
        }
        else if (rid.ToString() == "3")
        {
            Response.Write("<script>alert('board data updated.');</script>");
        }
        fillgrid();
    }
    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "btnrptredit")
        {
            board_masterBAL subjBAL = new board_masterBAL();
            subjBAL.board_id = Convert.ToInt16(e.CommandArgument.ToString());
            board_masterDAL mdmDAL = new board_masterDAL();
            DataSet ds = mdmDAL.get_single_board_detail(subjBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                hfboardid.Value = ds.Tables[0].Rows[0]["board_id"].ToString();
                txtboardname.Text = ds.Tables[0].Rows[0]["board_name"].ToString();
            }
            else
            {
                Response.Write("<script>alert('Such data does not exists');</script>");
            }
        }
    }

}