﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class admin_Admin_distric_add : System.Web.UI.Page
{

    void rptr_gridfilldata()
    {
        alladdress_get_data_DAL allDAL = new alladdress_get_data_DAL();
        DataSet ds = allDAL.taluka_data();

        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }

    void country_data()
    {

        alladdress_get_data_DAL allDAL = new alladdress_get_data_DAL();
        DataSet ds = allDAL.distric_data();

        if (ds.Tables[0].Rows.Count > 0)
        {
            drDistrict.DataSource = ds;
            drDistrict.DataTextField = "distric_name";
            drDistrict.DataValueField = "distric_id";
            drDistrict.DataBind();
            drDistrict.Items.Insert(0, "---: Select Distric :---");
        }
        else
        {
            drDistrict.DataSource = null;
            drDistrict.Items.Insert(0, "---Select Distric--");
            drDistrict.DataBind();
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["admin_login"] != null)
            {
                country_data();
                rptr_gridfilldata();
            }
            else
            {
                Response.Redirect("Admin_Login.aspx");
            }
        }
    }
    protected void drCountry_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void btnevent_Click(object sender, EventArgs e)
    {

        if (drDistrict.SelectedIndex != 0)
        {
            taluka_master_BAL dmBAL = new taluka_master_BAL();
            if (hfprdid.Value == "")
            {
                dmBAL.taluka_id = 0;
            }
            else
            {
                dmBAL.taluka_id = Convert.ToInt16(hfprdid.Value);
            }
            dmBAL.taluka_distric_id = Convert.ToInt16(drDistrict.SelectedValue);
            dmBAL.taluka_name = txttalukaname.Text.Trim().ToUpper();
            dmBAL.taluka_insdt = System.DateTime.Now.ToString("yyyy/MM/dd");
            dmBAL.taluka_insrid = Convert.ToInt16(Session["admin_login"].ToString());
            dmBAL.taluka_logdt = System.DateTime.Now.ToString("yyyy/MM/dd");
            dmBAL.taluka_logrid = Convert.ToInt16(Session["admin_login"].ToString());

            alladdress_insert_data_DAL allinDAL = new alladdress_insert_data_DAL();
            int val = allinDAL.taluka_data_insert(dmBAL);
            if (val == 1)
            {
                // show message for alredy exists
                Response.Write("<script>alert('This Taluka is exists.')</script>");

            }
            else if (val == 2)
            {
                // insert
                Response.Write("<script>alert('Taluka data inserted.');window.location.href='Admin_taluka_add.aspx';</script>");
            }
            else if (val == 3)
            {
                Response.Write("<script>alert('Taluka data updated.');window.location.href='Admin_taluka_add.aspx';</script>");
            }
        }
        else
        {
            Response.Write("<script>alert('Select your Distric.')</script>");
        }

    }
    protected void gridrepeater_ItemCommand1(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "editdata")
        {
            taluka_master_BAL taBAL = new taluka_master_BAL();
            taBAL.taluka_id = Convert.ToInt16(e.CommandArgument.ToString());

            alladdress_edit_data_DAL aleDAL = new alladdress_edit_data_DAL();
            DataSet ds = aleDAL.taluka_data_edit(taBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {

                drDistrict.SelectedValue = ds.Tables[0].Rows[0]["taluka_distric_id"].ToString();
                txttalukaname.Text = ds.Tables[0].Rows[0]["taluka_name"].ToString();
                hfprdid.Value = ds.Tables[0].Rows[0]["taluka_id"].ToString();
            }

        }

    }
}