﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class admin_Admin_country_add : System.Web.UI.Page
{
    void country_data()
    {
        alladdress_get_data_DAL alldata = new alladdress_get_data_DAL();
        DataSet ds = alldata.country_data();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["admin_login"] != null)
            {
                country_data();
            }
            else
            {
                Response.Redirect("Admin_Login.aspx");
            }
        }
    }
    protected void btnevent_Click(object sender, EventArgs e)
    {
        country_master_BAL cmBAL = new country_master_BAL();
        if (hfprdid.Value == "")
        {
            cmBAL.country_id = 0;
        }
        else
        {
            cmBAL.country_id = Convert.ToInt16(hfprdid.Value);
        }
        cmBAL.country_name = txtcountryname.Text.Trim().ToUpper();
        cmBAL.country_insdt = System.DateTime.Now.ToString("yyyy/MM/dd");
        cmBAL.country_insrid = Convert.ToInt16(Session["admin_login"].ToString());
        cmBAL.country_logdt = System.DateTime.Now.ToString("yyyy/MM/dd");
        cmBAL.country_logrid = Convert.ToInt16(Session["admin_login"].ToString());

        alladdress_insert_data_DAL allinDAL = new alladdress_insert_data_DAL();
        int val = allinDAL.country_data_insert(cmBAL);
        if (val == 1)
        {
            // show message for alredy exists
            Response.Write("<script>alert('This country is exists.')</script>");

        }
        else if (val == 2)
        {
            // insert
            Response.Write("<script>alert('country data inserted.');window.location.href='Admin_country_add.aspx';</script>");
        }
        else if (val == 3)
        {
            Response.Write("<script>alert('country data updated.');window.location.href='Admin_country_add.aspx';</script>");
        }
    }
    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "editdata")
        {
            country_master_BAL cmBAL = new country_master_BAL();
            cmBAL.country_id = Convert.ToInt16(e.CommandArgument);

            alladdress_edit_data_DAL aedDAL = new alladdress_edit_data_DAL();
            DataSet ds = aedDAL.country_data_edit(cmBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtcountryname.Text = ds.Tables[0].Rows[0]["country_name"].ToString();
                hfprdid.Value = ds.Tables[0].Rows[0]["country_id"].ToString();
            }

        }

    }
}