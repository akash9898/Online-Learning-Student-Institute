﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class homepage_after_login : System.Web.UI.Page
{
    void insitute_data_fill_clientid()
    {
        student_institute_link_BAL sdlBAL = new student_institute_link_BAL();
        sdlBAL.sil_verification_status = "1";
        sdlBAL.sil_stud_id = Convert.ToInt16(Session["clientlogin"].ToString());

        student_institute_link_DAL sdlDAL = new student_institute_link_DAL();
        DataSet ds = sdlDAL.student_institute_link_data_fill_verification_state_studant_data_show_institute(sdlBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            lblnoinstitute.Visible = false;
            rptinstitutedatafill.DataSource = ds;
            rptinstitutedatafill.DataBind();
        }
        else
        {
            lblnoinstitute.Visible = true;
            rptinstitutedatafill.DataSource = null;
            rptinstitutedatafill.DataBind();
        }

    }
    void fill_profile_data()
    {
        student_details_BAL sdBAL = new student_details_BAL();
        sdBAL.stud_id = Convert.ToInt16(Session["clientlogin"].ToString());

        student_details_DAL sdDAL = new student_details_DAL();
        DataSet ds = sdDAL.student_details_edit(sdBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            lbluserName.InnerText = ds.Tables[0].Rows[0]["stud_first_name"].ToString();
        }
    }
    void insitute_data_fill_notice_menu()
    {
        student_institute_link_BAL sdlBAL = new student_institute_link_BAL();
        sdlBAL.sil_verification_status = "1";
        sdlBAL.sil_stud_id = Convert.ToInt16(Session["clientlogin"].ToString());

        student_institute_link_DAL sdlDAL = new student_institute_link_DAL();
        DataSet ds = sdlDAL.student_institute_link_data_fill_verification_state_studant_data_show_institute(sdlBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            noticeinstitute.DataSource = ds;
            noticeinstitute.DataBind();
        }
        else
        {
            noticeinstitute.DataSource = null;
            noticeinstitute.DataBind();
        }

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["clientlogin"] != null)
            {
                insitute_data_fill_clientid();
                logoutdiv.Visible = true;
                homeli.Visible = false;
                logindiv.Visible = false;
                fill_profile_data();
                insitute_data_fill_notice_menu();
            }
            else
            {
                Response.Redirect("log_in.aspx");
            }
        }
    }

    protected void rptinstitutedatafill_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "institute")
        {
            if (Request.QueryString["notice"] != null)
            {
                //institute id use = unikhjn
                Response.Redirect("notice.aspx?unikhjn=" + e.CommandArgument);
            }
            else
            {
                //institute id use = unikhjn
                Response.Redirect("select_subject.aspx?unikhjn=" + e.CommandArgument);
            }
        }
    }
}