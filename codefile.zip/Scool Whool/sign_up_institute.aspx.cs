﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class sign_up_institute : System.Web.UI.Page
{
    void state_data()
    {
        alladdress_get_data_DAL aldataDAL = new alladdress_get_data_DAL();
        DataSet ds = aldataDAL.state_data();

        if (ds.Tables[0].Rows.Count > 0)
        {

            drstate.DataSource = ds;
            drstate.DataTextField = "state_name";
            drstate.DataValueField = "state_id";
            drstate.DataBind();
            drstate.Items.Insert(0, new ListItem("State", "0"));

        }
        else
        {
            drstate.Items.Clear();
        }
    }
    public void fill_distric_dropdown(int stateid)
    {

        distric_master_BAL cmBAL = new distric_master_BAL();
        cmBAL.distric_state_id = stateid;

        alladdress_get_data_DAL allDAL = new alladdress_get_data_DAL();
        DataSet ds = allDAL.state_and_distric_data(cmBAL);

        if (ds.Tables[0].Rows.Count > 0)
        {

            drdistric.DataSource = ds;
            drdistric.DataTextField = "distric_name";
            drdistric.DataValueField = "distric_id";
            drdistric.DataBind();
            drdistric.Items.Insert(0, new ListItem("District", "0"));

        }
        else
        {
            drdistric.DataSource = null;
            //   drdistric.Items.Insert(0, "---Select Distric--");
            drdistric.DataBind();
        }
    }
    public void fill_taluka_dropdown(int districtid)
    {
        taluka_master_BAL tdBAL = new taluka_master_BAL();
        tdBAL.taluka_distric_id = districtid;

        alladdress_get_data_DAL allDAL = new alladdress_get_data_DAL();
        DataSet ds = allDAL.distric_and_taluka_data(tdBAL);

        if (ds.Tables[0].Rows.Count > 0)
        {

            drtalika.DataSource = ds;
            drtalika.DataTextField = "taluka_name";
            drtalika.DataValueField = "taluka_id";
            drtalika.DataBind();
            drtalika.Items.Insert(0, new ListItem("Taluka", "0"));
        }
        else
        {
            drtalika.DataSource = null;
            drtalika.DataBind();
            //  drtalika.Items.Insert(0, "---Select Taluka--");
        }
    }

    void institute_type_data_fill_drop()
    {
        institute_type_master_DAL itmDAL = new institute_type_master_DAL();
        DataSet ds = itmDAL.institute_type_master_data_fill();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drinstitute.DataSource = ds;
            drinstitute.DataTextField = "institute_type_name";
            drinstitute.DataValueField = "institute_type_id";
            drinstitute.DataBind();
            drinstitute.Items.Insert(0, new ListItem("Type of Institute", "0"));
        }
        else
        {
            drinstitute.Items.Clear();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            state_data();
            institute_type_data_fill_drop();
        }
    }

    protected void drdistric_SelectedIndexChanged(object sender, EventArgs e)
    {
        fill_taluka_dropdown(Convert.ToInt32(drdistric.SelectedValue));
    }

    protected void drstate_SelectedIndexChanged(object sender, EventArgs e)
    {
        fill_distric_dropdown(Convert.ToInt32(drstate.SelectedValue));
    }
    protected void btnsignupinstitute_Click(object sender, EventArgs e)
    {
        institute_details_BAL idBAL = new institute_details_BAL();
        if (hfboardid.Value != null & hfboardid.Value.ToString() != "")
        {
            idBAL.id_id = Convert.ToInt16(hfboardid.Value.ToString());
        }
        else
        {
            idBAL.id_id = 0;
        }
        idBAL.id_institute_code = "9898";
        idBAL.id_type = Convert.ToInt16(drinstitute.SelectedItem.Value);
        idBAL.id_name = txtname.Text;
        idBAL.id_mobile_no = txtmobileno.Text;
        idBAL.id_email = txtemailid.Text;
        idBAL.id_email_verification = "0";
        idBAL.id_website = txtwebsite.Text;
        idBAL.id_website_verification = "0";
        idBAL.id_address_line_1 = txtaddress.Text;
        idBAL.id_address_line_2 = txtaddressline.Text;
        idBAL.id_landmark = txtLandmark.Text;
        idBAL.id_state_id = Convert.ToInt16(drstate.SelectedItem.Value);
        idBAL.id_district_id = Convert.ToInt16(drdistric.SelectedItem.Value);
        idBAL.id_tahesil_id = Convert.ToInt16(drtalika.SelectedItem.Value);
        idBAL.id_password = txtpassword.Text;
        idBAL.id_verification_status = "0";
        idBAL.id_date_of_registration = System.DateTime.Now;
        idBAL.id_logdt = System.DateTime.Now;
        idBAL.id_logrid = 1;

        institute_details_DAL idDAL = new institute_details_DAL();
        int val = idDAL.institute_details_insert(idBAL);
        if (val.ToString() == "1")
        {
            Response.Write("<script>alert('Sorry this contact number or email address is attached with other institute');</script>");
        }
        else if (val.ToString() == "2")
        {
            Response.Write("<script>alert('Thank you for registering with us we will get back to you shortly');window.location.href='index.aspx';</script>");
        }
        else if (val.ToString() == "3")
        {
            Response.Write("<script>alert('Institute data updated.');window.location.href='sign_up_institute.aspx';</script>");
        }
    }
}